package interfaces;

import javax.swing.*;

public interface ButtonAction 
{
    public void setButtonClickListener(JButton button);
}
